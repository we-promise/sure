# Changelog

All notable changes to the Sure Helm chart will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and chart releases follow Sure’s [calendar versioning](../../docs/releases/versioning.md).

## [Unreleased]

### Changed
- Pipelock's MCP listener now starts with Pipelock 3.2+, which refuses a non-loopback listener without auth. It defaults to `pipelock.mcpProxy.allowUnauthenticated: true`; rendering fails with a clear message if neither option is set.

### Added
- `pipelock.mcpProxy.authTokenSecret`: require a Pipelock listener token from an existing Secret.

## [0.7.4] - 2026-08-31

### Changed
- Updated the Pipelock CI action and deployment image from 2.8.0 to 3.4.0. The image uses the release's multi-architecture manifest digest.
- CI now runs Pipelock's built-in test vectors and validates the Compose config plus the Helm-rendered `pipelock.yaml` with the pinned binary.
- Corrected the HTTPS coverage docs. The default examples apply tunnel-level controls but can't inspect encrypted request or response bodies without TLS interception.
- Helm now rejects external-assistant deployments without Pipelock by default. Operators can set `pipelock.requireForExternalAssistant=false` to accept direct traffic.
- Bumped `pipelock.image.tag` from `2.5.0` to `2.8.0`, picking up default-on flight recorder receipts, safe-by-default receipt verification, MCP `defer` authorization, `pipelock explain`, `pipelock keys status`, `pipelock support bundle`, verified self-update, and inert-exemption diagnostics.
- Refreshed Pipelock docs across Docker, MCP, AI, and chart setup to distinguish scanning from verifiable receipt evidence.
- Enabled `pipelock.requestBodyScanning` by default with `action: warn`, matching Pipelock's current balanced preset so outbound prompt bodies and sensitive headers are scanned.

### Added
- `pipelock.flightRecorder`: structured Helm values for rendering `flight_recorder.enabled`, `require_receipts`, `redact`, `dir`, and `signing_key_path`.
- `pipelock.extraVolumes` and `pipelock.extraVolumeMounts`: mount receipt evidence storage and receipt-signing keys without duplicating the Pipelock deployment template.

## [0.7.1] - 2026-05-31

### Changed
- Bumped `pipelock.image.tag` from `2.2.0` to `2.5.0`. Picks up three releases of scanner, federation, and audit work — see the [pipelock changelog](https://github.com/luckyPipewrench/pipelock/blob/main/CHANGELOG.md) for the full surface.
- Refreshed pipelock feature notes in the chart README, `docs/hosting/pipelock.md`, and `pipelock.example.yaml` to call out 2.5 highlights (Audit Packet v0, request-body prompt-injection blocking, SPIFFE-strict inbound envelopes, scanner attribution on MCP block receipts).
- Expanded the `pipelock.extraConfig` escape-hatch comment to reference the new sections available in 2.5 (browser_shield, mediation_envelope, redaction, learn, media_policy, a2a_scanning, emit).
- Defaulted `pipelock.mcpToolPolicy.enabled` to `false`. Pipelock 2.x rejects an enabled `mcp_tool_policy` with no rules, so the prior chart default (`enabled: true`, empty rules) hard-failed config validation on startup. Operators who want tool policy active must now set `enabled: true` and provide at least one entry in `pipelock.mcpToolPolicy.rules`.

### Added
- `pipelock.requestBodyScanning` (pipelock 2.5+): structured config for scanning outbound request bodies for prompt-injection and bodies/sensitive headers for DLP payloads. Disabled by default to preserve existing chart behavior; opt in with `enabled: true`.
- `pipelock.healthWatchdog` (pipelock 2.4+): structured config for the wedge-detection watchdog. Operators can opt into per-subsystem detail in `/health` responses via `exposeSubsystems: true`.
- `pipelock.mcpToolPolicy.rules`: structured Helm values for rendering `mcp_tool_policy.rules`, including redirect-profile references.
- `asserts.tpl` guard that fails `helm template`/`helm install` when `pipelock.mcpToolPolicy.enabled=true` is paired with an empty `rules` list, surfacing the pipelock validation error at render time instead of container startup.
- README: CI scan status badge for the pipelock workflow.

## [0.6.9] - 2026-03-31

### Changed
- Bumped `pipelock.image.tag` from `1.5.0` to `2.0.0`
- CI: Pipelock GitHub Action updated from `@v1` to `@v2`
- Compose example image changed from pinned `1.5.0` to `latest` with pin comment
- Bumped `pipelock.image.tag` from `0.3.1` to `0.3.2`
- Consolidated `compose.example.pipelock.yml` into `compose.example.ai.yml` — Pipelock now runs alongside Ollama in one compose file with health checks, config volume mount, and MCP env vars (`MCP_API_TOKEN`, `MCP_USER_EMAIL`)
- CI: Pipelock scan `fail-on-findings` changed from `false` to `true`; added `exclude-paths` for locale help text false positives

### Added
- **Pipelock v2.0 features**:
  - `pipelock.trustedDomains`: first-class support for allowing internal services whose public DNS resolves to private IPs (prevents SSRF false positives)
  - `pipelock.mcpToolPolicy.redirectProfiles`: route matched MCP tool calls to audited handler programs instead of blocking
  - Updated `pipelock.example.yaml` with v2.0 feature documentation (trusted domains, redirect profiles, attack simulation, security scoring)
  - Updated `extraConfig` comment to mention new v2.0 sections (sandbox, reverse_proxy)
- Pipelock v2.0 highlights available via `extraConfig`: process sandbox (Linux/macOS), generic HTTP reverse proxy, adaptive enforcement exempt domains, kill switch API port isolation
- **Bumped** `pipelock.image.tag` from `0.3.2` to `1.5.0`
- **Pipelock security proxy** (`pipelock.enabled=true`): Separate Deployment + Service that provides two scanning layers
  - **Forward proxy** (port 8888): Scans outbound HTTPS from Faraday-based clients (e.g. ruby-openai). Auto-injects `HTTPS_PROXY`/`HTTP_PROXY`/`NO_PROXY` env vars into app pods
  - **MCP reverse proxy** (port 8889): Scans inbound MCP traffic for DLP, prompt injection, and tool poisoning. Auto-computes upstream URL via `sure.pipelockUpstream` helper
  - **WebSocket proxy** configuration support (disabled by default)
  - ConfigMap with scanning config (DLP, prompt injection detection, MCP input/tool scanning, response scanning)
  - ConfigMap checksum annotation for automatic pod restart on config changes
  - Helm helpers: `sure.pipelockImage`, `sure.pipelockUpstream`
  - Health and readiness probes on the Pipelock deployment
  - `imagePullSecrets` with fallback to app-level secrets
  - Boolean safety: uses `hasKey` to prevent Helm's `default` from swallowing explicit `false`
  - Configurable ports via `forwardProxy.port` and `mcpProxy.port` (single source of truth across Service, Deployment, and env vars)
- `pipelock.example.yaml` reference config for Docker Compose deployments
- **Pipelock operational hardening**:
  - `pipelock.serviceMonitor`: Prometheus Operator ServiceMonitor for /metrics on the proxy port
  - `pipelock.ingress`: Ingress template for MCP reverse proxy (external AI assistant access in k8s)
  - `pipelock.pdb`: PodDisruptionBudget with minAvailable/maxUnavailable mutual exclusion guard
  - `pipelock.topologySpreadConstraints`: Pod spread across nodes
  - `pipelock.logging`: Structured logging config (format, output, include_allowed, include_blocked)
  - `pipelock.extraConfig`: Escape hatch for additional pipelock.yaml config sections
  - `pipelock.requireForExternalAssistant`: Helm guard that fails when externalAssistant is enabled without pipelock
  - Component label (`app.kubernetes.io/component: pipelock`) on Service metadata for selector targeting
  - NOTES.txt: Pipelock health check commands, MCP access info, security notes, metrics status

### Fixed
- Renamed `_asserts.tpl` to `asserts.tpl` — Helm's `_` prefix convention prevented guards from executing

## [0.6.7] - 2026-01-31

### Added
- **Redis Sentinel support for Sidekiq high availability**: Application now automatically detects and configures Sidekiq to use Redis Sentinel when `redisOperator.mode=sentinel` and `redisOperator.sentinel.enabled=true`
  - New Helm template helpers (`sure.redisSentinelEnabled`, `sure.redisSentinelHosts`, `sure.redisSentinelMaster`) for Sentinel configuration detection
  - Automatic injection of `REDIS_SENTINEL_HOSTS` and `REDIS_SENTINEL_MASTER` environment variables when Sentinel mode is enabled
  - Sidekiq configuration supports Sentinel authentication with `sentinel_username` (defaults to "default") and `sentinel_password`
  - Robust validation of Sentinel endpoints with port range checking (1-65535) and graceful fallback to direct Redis URL on invalid configuration
  - Production-ready HA timeouts: 200ms connect, 1s read/write, 3 reconnection attempts
  - Backward compatible with existing `REDIS_URL` deployments

### [0.6.6] - 2025-12-31

### Added

- First version/release that aligns versions with monorepo
- CNPG: render `Cluster.spec.backup` from `cnpg.cluster.backup`.
  - If `backup.method` is omitted and `backup.volumeSnapshot` is present, the chart will infer `method: volumeSnapshot`.
  - For snapshot backups, `backup.volumeSnapshot.className` is required (template fails early if missing).
  - Example-only keys like `backup.ttl` and `backup.volumeSnapshot.enabled` are stripped to avoid CRD warnings.
- CNPG: render `Cluster.spec.plugins` from `cnpg.cluster.plugins` (enables barman-cloud plugin / WAL archiver configuration).

### [0.0.0], [0.6.5]

### Added

- First (nightly/test) releases via <https://we-promise.github.io/sure/index.yaml>

## Notes
- Chart version and application version are kept in sync
- Requires Kubernetes >= 1.25.0
- When upgrading from pre-Sentinel configurations, existing deployments using `REDIS_URL` continue to work unchanged
